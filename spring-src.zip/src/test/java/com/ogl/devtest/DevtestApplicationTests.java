package com.ogl.devtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevtestApplicationTests {

  @Test
  void contextLoads() {
  }

}
