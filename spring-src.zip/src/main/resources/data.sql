INSERT INTO product (id, sku, price, description)
VALUES (DEFAULT, 'AAA001', 5.99, 'To be entered'),
       (DEFAULT, 'AAA002', 10.00, 'To be entered'),
       (DEFAULT, 'BBB001', 0.69, 'To be entered');

INSERT INTO customer (id, name, street, city, county, postcode)
VALUES (DEFAULT, 'Rick Sanchez', '66 Oxford drive', 'London', 'London', 'kt5 0ty'),
       (DEFAULT, 'Walter White', '52 kent street', 'Bedford', ' Bedfordshire', 'BA4 8FG'),
       (DEFAULT, 'William Butcher', '90 Butts road', 'Northampton', 'Northamptonshire', 'NN1 1AA');